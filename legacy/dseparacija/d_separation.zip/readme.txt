
POMEMBNO:
V mapi Windows je različica skripte, ki deluje na windowsu. Posebej je zato, ker je knjižnica graphviz_layout "notoriously difficult to install on a windows machine" (iz njihove spletne strani).
graphviz_layout graf skuša izrisati v obliki oče-sin, ker tega na windows ni, je na linux/macos operacijskih sistemih izris lahko malo bolj pregleden.

d_separation.py: V moder okvir zapišite povezave, kliknite generiraj graf. Nato izberite dve vozlišči in kliknete "Find D-separating sets". V terminalu je podrobnejši izpis postopka.
d_separation_practice.py: Generirajte graf, izberite vozlišča in preverite svojo rešitev. Prav tako je v terminalu izpis postopka.



